﻿
namespace DBMananger
{
    partial class frminput
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInput = new System.Windows.Forms.Label();
            this.tbfrminput = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblInput
            // 
            this.lblInput.AutoSize = true;
            this.lblInput.Font = new System.Drawing.Font("굴림", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblInput.Location = new System.Drawing.Point(35, 19);
            this.lblInput.Name = "lblInput";
            this.lblInput.Size = new System.Drawing.Size(47, 19);
            this.lblInput.TabIndex = 0;
            this.lblInput.Text = "Input";
            // 
            // tbfrminput
            // 
            this.tbfrminput.Location = new System.Drawing.Point(39, 42);
            this.tbfrminput.Name = "tbfrminput";
            this.tbfrminput.Size = new System.Drawing.Size(209, 25);
            this.tbfrminput.TabIndex = 1;
            this.tbfrminput.TextChanged += new System.EventHandler(this.tbfrminput_TextChanged);
            this.tbfrminput.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbfrminput_KeyDown);
            // 
            // frminput
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(299, 95);
            this.Controls.Add(this.tbfrminput);
            this.Controls.Add(this.lblInput);
            this.Cursor = System.Windows.Forms.Cursors.No;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frminput";
            this.Text = "frminput";
            this.Load += new System.EventHandler(this.frminput_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInput;
        private System.Windows.Forms.TextBox tbfrminput;
    }
}