﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyClassLibray
{
    public partial class UserControl1: UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }




        }
        public class myLib
        {
            public static int Count(char deli, string str) //str 문자열 deli 구분자의 개수 +1
            {
                string[] Strs = str.Split(deli);
                int n = Strs.Length;
                return n - 1;
            }
            public static string GetToken(int index, char deli, string str)
            {
                string[] Strs = str.Split('\\');
                //int n = Strs.Length;
                string ret = Strs[index];
                return ret;

            }
    }
}
