﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBMananger
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mnuMigration_Click(object sender, EventArgs e)
        {
            DialogResult ret =openFileDialog1.ShowDialog();  // OpenFileDialog 안에 초기화가 있으므로 new(생성자 호출) 를 쓸필요없다
            if (ret != DialogResult.OK) return;
            string nFile = openFileDialog1.FileName; //full name

            StreamReader sr = new StreamReader(nFile);

            // Header 처리 프로세스 //
            string buf = sr.ReadLine(); // 한줄만 읽은것이다
            if (buf == null) return;

            string[] sArr = buf.Split(',');
            for (int i = 0; i < sArr.Length; i++)
                {
                    dataGrid.Columns.Add(sArr[i], sArr[i]);
                }

            // Row 데이터 처리 프로세스 //
            while (true) // while(1) 은 안된다
            {
                buf = sr.ReadLine(); // 한줄만 읽은것이다
                if (buf == null) break;
                int rIdx = dataGrid.Rows.Add();
                sArr = buf.Split(',');
          
             
                for (int i = 0; i < sArr.Length; i++)        // -->>> 간단히 for문을 ==> dataGrid.Rows.Add(sArr); 이렇게 최소화하여도 된다.
                {
                    dataGrid.Rows[rIdx].Cells[i].Value = sArr[i];

                }
             

                /*
                int n = 0;
                while(true) // while(1) 은 안된다
                {
                    string buf = sr.ReadLine(); // 한줄만 읽은것이다
                    if (buf == null) break;
                    if (n == 0)
                    {
                        string[] sArr = buf.Split(',');
                       // C# -> int[] arr = new int[100]; // int[] 는 배열형이다.
                       for (int i=0;i<sArr.Length;i++)
                        {
                            dataGrid.Columns.Add(sArr[i],sArr[i]);
                        }
                    }
                    else
                    {
                        int rIdx = dataGrid.Rows.Add();
                        string[] sArr = buf.Split(',');
                        for (int i = 0; i < sArr.Length; i++)
                        {
                            dataGrid.Rows[rIdx].Cells[i].Value = sArr[i];

                        }
                    }
                    n++;
                */
            }
           
            
        }

        SqlConnection sqlCon = new SqlConnection(); // DB를 열기위해 필요하다 새로운클래스이기에 생성해줘야한다.
        SqlCommand sqlCmd = new SqlCommand();
        string sConn = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=;Integrated Security=True;Connect Timeout=30";


        private void mnuDBOpen_Click(object sender, EventArgs e)
        {
            try // try 하고 안되면 catch로 예외처리
            {
                DialogResult ret = openFileDialog1.ShowDialog();  // db file
  
                if (ret != DialogResult.OK) return;
                string nFile = openFileDialog1.FileName; //full name
                string[] ss = sConn.Split(';');


                sqlCmd.Connection = sqlCon;  // SqlCommand 는 SqlConnection에 종속되어야한다.
              //sqlCon.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\KOSTA\source\repos\DBMananger\TestDB.mdf;Integrated Security=True;Connect Timeout=30";

                sqlCon.ConnectionString = $"{ss[0]};{ss[1]}{nFile};{ss[2]};{ss[3]}";
                sqlCon.Open();
                sbPanel1.Text = openFileDialog1.SafeFileName;
                sbPanel2.Text = " DB File success";
                sbPanel1.BackColor = Color.Green;
            }
            catch(SqlException e1)
            {
                MessageBox.Show(e1.Message);
                sbPanel2.Text = " DB File can not open";
                sbPanel2.BackColor = Color.Red;
            }

    

        }

        public static string GetToken(int index, char deli, string str)
        {
            string[] Strs = str.Split(deli);
            //int n = Strs.Length;
            string ret = Strs[index];
            return ret;

        }
        string TableName;


        int RunSql(string s1)
        {
            try
            {
                string sql = s1.Trim(); // Trim : 앞뒤 공백을 없앤다. (중간 공백은 빼고)
                sqlCmd.CommandText = sql; // insert into fstatus values (1,2,3,4) 
                if (GetToken(0,' ',sql).ToUpper()=="SELECT")  // ToUpper로 대문자로 만들어줬으므로 걱정 없다
                {
                    SqlDataReader sr = sqlCmd.ExecuteReader();
                    TableName = GetToken(3, ' ', sql);
                    dataGrid.Rows.Clear();
                    dataGrid.Columns.Clear();
                   

                    for (int i = 0; i < sr.FieldCount; i++)   // Header 처리 프로세스 //
                    {
                        dataGrid.Columns.Add(sr.GetName(i), sr.GetName(i));
                    }


                    for (int i = 0; sr.Read(); i++)
                    {
                        int rIdx = dataGrid.Rows.Add();
                        for (int j = 0; j < sr.FieldCount; j++)
                        {
                            object str = sr.GetValue(j);
                            dataGrid.Rows[rIdx].Cells[j].Value = str;
                        }
                    }



                    /*
                    for (int i=0;sr.Read();i++)
                    {
                        string buf = "";
                        for(int j=0;j<sr.FieldCount;j++)
                        {                           
                            object str = sr.GetValue(j);
                            buf += $" {str}";                                               
                        }

                        tbSql.Text += $"\r\n{buf}";                                                                   
                    }
                     */

                    sr.Close();
                }
                else
                {
                    sqlCmd.ExecuteNonQuery(); // select 문 제외 -- no retrun value
                                              // update ,insert ,delete ,create, alt 
                }
           
                //sqlCmd.ExecuteReader();
                sbPanel2.Text = "Success";
                sbPanel2.BackColor = Color.DeepPink;
            }
            catch(SqlException e1)
            {
                MessageBox.Show(e1.Message);
                sbPanel2.Text = "Error";
                sbPanel2.BackColor = Color.Red;
            }
            catch(InvalidOperationException e2)
            {
                MessageBox.Show(e2.Message);
                sbPanel2.Text = "Error";
                sbPanel2.BackColor = Color.Red;

            }
              return 0;
        }

        private void mnuExecSql_Click(object sender, EventArgs e)
        {
            RunSql(tbSql.Text);

            //string sql = tbSql.Text;
            //sqlCmd.CommandText = sql;
            //sqlCmd.ExecuteNonQuery();

        }

        private void mnuSelSql_Click(object sender, EventArgs e)
        {
            RunSql(tbSql.SelectedText);

            //string sql = tbSql.SelectedText;
            //sqlCmd.CommandText = sql;
            //sqlCmd.ExecuteNonQuery();
        }



        private void tbSql_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter) return;

            string str = tbSql.Text;
            string[] sArr = str.Split('\n'); // 줄바꿈문자 :\r\n
            int n = sArr.Length;
            string sql = sArr[n - 1].Trim();

            RunSql(sql);

        }

        private void dataGrid_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            dataGrid.Rows[e.RowIndex].Cells[e.ColumnIndex].ToolTipText=".";
            // object 를 string 캐스팅하는거는 ㄱㅊ , string 을 object 캐스팅 : 안 ㄱㅊ
            
        }

        private void dB업데이트ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for(int i=0;i<dataGrid.Rows.Count;i++)
            {
                for(int j=0;j<dataGrid.Columns.Count;j++)
                {
                    string s = dataGrid.Rows[i].Cells[j].ToolTipText;
                    if(s==".")
                    // update [Table] set [field] = [CellText] where [Key Name]=[Key.CellText]
                    // update status set Temp = 10 where id=5  이런 느낌이다.
                    {
                        string tn = TableName;
                        string fn = dataGrid.Columns[j].HeaderText;
                        string ct = (string)dataGrid.Rows[i].Cells[j].Value;
                        string kn= dataGrid.Columns[0].HeaderText;
                        int kt = (int)dataGrid.Rows[i].Cells[0].Value;
                        string sql = $"update {tn} set {fn}={ct} where {kn}={kt}";

                        RunSql(sql);

                    }
                }
            }
        }
    }
}
