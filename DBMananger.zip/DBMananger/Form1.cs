﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBMananger
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mnuMigration_Click(object sender, EventArgs e)
        {
            DialogResult ret =openFileDialog1.ShowDialog();  // OpenFileDialog 안에 초기화가 있으므로 new(생성자 호출) 를 쓸필요없다
            if (ret != DialogResult.OK) return;
            string nFile = openFileDialog1.FileName; //full name

            StreamReader sr = new StreamReader(nFile);

            // Header 처리 프로세스 //
            string buf = sr.ReadLine(); // 한줄만 읽은것이다
            if (buf == null) return;

            string[] sArr = buf.Split(',');
            for (int i = 0; i < sArr.Length; i++)
                {
                    dataGrid.Columns.Add(sArr[i], sArr[i]);
                }

            // Row 데이터 처리 프로세스 //
            while (true) // while(1) 은 안된다
            {
                buf = sr.ReadLine(); // 한줄만 읽은것이다
                if (buf == null) break;
                int rIdx = dataGrid.Rows.Add();
                sArr = buf.Split(',');
          
             
                for (int i = 0; i < sArr.Length; i++)        // -->>> 간단히 for문을 ==> dataGrid.Rows.Add(sArr); 이렇게 최소화하여도 된다.
                {
                    dataGrid.Rows[rIdx].Cells[i].Value = sArr[i];

                }
             

                /*
                int n = 0;
                while(true) // while(1) 은 안된다
                {
                    string buf = sr.ReadLine(); // 한줄만 읽은것이다
                    if (buf == null) break;
                    if (n == 0)
                    {
                        string[] sArr = buf.Split(',');
                       // C# -> int[] arr = new int[100]; // int[] 는 배열형이다.
                       for (int i=0;i<sArr.Length;i++)
                        {
                            dataGrid.Columns.Add(sArr[i],sArr[i]);
                        }
                    }
                    else
                    {
                        int rIdx = dataGrid.Rows.Add();
                        string[] sArr = buf.Split(',');
                        for (int i = 0; i < sArr.Length; i++)
                        {
                            dataGrid.Rows[rIdx].Cells[i].Value = sArr[i];

                        }
                    }
                    n++;
                */
            }
           
            
        }

        SqlConnection sqlCon = new SqlConnection(); // DB를 열기위해 필요하다 새로운클래스이기에 생성해줘야한다.
        SqlCommand sqlCmd = new SqlCommand();
        string sConn = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=;Integrated Security=True;Connect Timeout=30";


        private void mnuDBOpen_Click(object sender, EventArgs e)
        {
            try // try 하고 안되면 catch로 예외처리
            {
                DialogResult ret = openFileDialog1.ShowDialog();  // db file
  
                if (ret != DialogResult.OK) return;
                string nFile = openFileDialog1.FileName; //full name
                string[] ss = sConn.Split(';');


                sqlCmd.Connection = sqlCon;  // SqlCommand 는 SqlConnection에 종속되어야한다.
              //sqlCon.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\KOSTA\source\repos\DBMananger\TestDB.mdf;Integrated Security=True;Connect Timeout=30";

                sqlCon.ConnectionString = $"{ss[0]};{ss[1]}{nFile};{ss[2]};{ss[3]}";
                sqlCon.Open();
                sbPanel1.Text = openFileDialog1.SafeFileName;
                sbPanel2.Text = " DB File success";
                sbPanel2.BackColor = Color.Green;
            }
            catch(SqlException e1)
            {
                MessageBox.Show(e1.Message);
                sbPanel2.Text = " DB File can not open";
                sbPanel2.BackColor = Color.Red;
            }

    

        }

        int RunSql(string sql)
        {
            try
            {
                sqlCmd.CommandText = sql;
                sqlCmd.ExecuteNonQuery(); // select 문 제외 -- no retrun value
                                          // update ,insert ,delete ,create, alt           
                //sqlCmd.ExecuteReader();
            }
            catch(SqlException e1)
            {
                MessageBox.Show(e1.Message);
            }
            catch(InvalidOperationException e2)
            {
                MessageBox.Show(e2.Message);
            }
              return 0;
        }

        private void mnuExecSql_Click(object sender, EventArgs e)
        {
            RunSql(tbSql.Text);

            //string sql = tbSql.Text;
            //sqlCmd.CommandText = sql;
            //sqlCmd.ExecuteNonQuery();

        }

        private void mnuSelSql_Click(object sender, EventArgs e)
        {
            RunSql(tbSql.SelectedText);

            //string sql = tbSql.SelectedText;
            //sqlCmd.CommandText = sql;
            //sqlCmd.ExecuteNonQuery();
        }
    }
}
