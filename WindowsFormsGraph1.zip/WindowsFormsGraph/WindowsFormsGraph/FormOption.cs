﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsGraph
{
    public partial class FormOption : Form
    {
        public int X, Y;
        public int Thick;
        public Color Col1;
        public string ColorName;

        public FormOption(int x,int y,int t)    // 생성자
        {
            X = x; Y = y; Thick = t;
            InitializeComponent();
        }

        

        private void FormOption_Load(object sender, EventArgs e)
        {
            tbSizeX.Text = $"{X}"; // 보간문자열
            tbSizeY.Text = $"{Y}";
            tbThickness.Text = $"{Thick}";
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            DialogResult ret = colorDialog1.ShowDialog();
            if(ret==DialogResult.OK)
            {
                Col1 = colorDialog1.Color;
                tbColor.Text = $"{Col1.ToArgb()}";
            }
        }

        private void FormOption_FormClosing(object sender, FormClosingEventArgs e)
        {
            ColorName = tbColor.Text;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            X = int.Parse(tbSizeX.Text);
            Y = int.Parse(tbSizeY.Text);
            Thick = int.Parse(tbThickness.Text);
        }
    }
}
