﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsGraph
{
    public partial class Form1 : Form
    {
        Graphics GDC;

        public Form1()
        {
            InitializeComponent();

            GDC = CanvasDraw.CreateGraphics();
        }

        private void CanvasDraw_Paint(object sender, PaintEventArgs e)
        {
        //    Pen po = new Pen(Color.Red, 10);
        //    e.Graphics.DrawEllipse(po,100,100,200,200);
        }

        private void mnuDraw_Click(object sender, EventArgs e)
        {
            
            
        }




        private void CanvasDraw_Resize(object sender, EventArgs e)
        {
            GDC = CanvasDraw.CreateGraphics();
        }

        private void mnuErase_Click(object sender, EventArgs e)
        {
            GDC.Clear(DefaultBackColor);
        }
        int CirX = 10;
        int CirY = 10;
        int CirThick=2;
        private void mnuOption_Click(object sender, EventArgs e)
        {
            FormOption dlg = new FormOption (CirX,CirY,CirThick);
            DialogResult ret = dlg.ShowDialog();
            if (ret == DialogResult.OK) //착한사용자인 경우
            {
                CirX = dlg.X;
                CirY = dlg.Y;
                CirThick = dlg.Thick;
                col = dlg.Col1;
                sbPanel3.Text = $"{dlg.ColorName},{CirThick}";
              

            }
        }

        bool MStaus = false; // false(0):그리기 상태아님 , true(1): 그리기상태
        int DrawMode = -1; // -1 :none 0 : pen  1: circle 2: Arc 3: Line
        Point p1;
        Color col = Color.Red;  //

        private void CanvasDraw_MouseDown(object sender, MouseEventArgs e) // 마우스 눌렀을때 이벤트 처리기
        {

            /* if(e.Button == MouseButtons.Left)            // Circle 만들기
             {
                 Pen po = new Pen(Color.Red, CirThick);
                 GDC.DrawEllipse(po, e.X - CirX/2 , e.Y - CirY/2 , CirX, CirY);
             }*/
            if(DrawMode==0)
            {
            p1 = new Point(e.X, e.Y);
            MStaus = true;
            }
            else if (DrawMode == 1)  // 원 그리기   따로  MouseMove, MouseUp 안에 한붓그리기 처럼 따로 추가안해줘도 된다.
            {
                if (e.Button == MouseButtons.Left)            // Circle 만들기
                {
                    Pen po = new Pen(col, CirThick);
                    GDC.DrawEllipse(po, e.X - CirX / 2, e.Y - CirY / 2, CirX, CirY);
                }
            }

        }

        private void CanvasDraw_MouseMove(object sender, MouseEventArgs e)
        {
            int x = e.X;
            int y = e.Y;
            string sx = $"{x}";
            string sy = $"{y}";
            if (DrawMode == 0)  // 한붓 그리기
            { 
                if (MStaus) // (MStaus == true)
                {
                 Pen pp = new Pen(col, CirThick); 
                 Point p2 = new Point(e.X, e.Y);
                 GDC.DrawLine(pp,p1,p2);
                 p1 = p2;
                 }
            }


            sbPanel1.Text = $"{e.X}, {e.Y}";
            
          
        }

        private void CanvasDraw_MouseUp(object sender, MouseEventArgs e)
        {
            if (DrawMode == 0)
            {
                MStaus = false;
            }
            
        }





        /*
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            Pen po = new Pen(Color.Red, 10);
            GDC.DrawEllipse(po, e.X, e.Y, 200, 200);
        }
        */

        //private void DrawArcRectangle(object sender, PaintEventArgs e)
        //{
            
        //    Pen popo = new Pen(Color.Black, 3);

        //    Rectangle rect = new Rectangle(0, 0, 100, 200);

        //    float startAngle = 45.0F;
        //    float sweepAngle = 270.0F;

        //    e.Graphics.DrawArc(popo, rect, startAngle, sweepAngle);
        //}

        private void mnuDrawStop_Click(object sender, EventArgs e)
        {
            DrawMode = -1;
            sbPanel2.Text = "그리기 모드";
        }
        private void mnuDrawPen_Click(object sender, EventArgs e)
        {
            DrawMode = 0;
            sbPanel2.Text = "한붓 그리기";
            sbPanel3.Text = $"{col}";

        }

        private void mnuDrawCircle_Click(object sender, EventArgs e)
        {
            DrawMode = 1;
            sbPanel2.Text = "원 그리기";
        }

        private void mnuDrawArc_Click(object sender, EventArgs e)
        {
            DrawMode = 2;
            sbPanel2.Text = "호(Arc) 그리기";
        }

        private void mnuDrawLine_Click(object sender, EventArgs e)
        {
            DrawMode = 3;
            sbPanel2.Text = "선 그리기";
        }

    }
}
